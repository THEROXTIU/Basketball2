package com.example.basketballscore

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.basketballscore.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var viewModel: MainViewModel
    private fun openrestartactivity() {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)

        val Toast = Toast.makeText(
            applicationContext,
            "Se ha reiniciado en ceros el marcador",
            Toast.LENGTH_LONG
        )
        Toast.setGravity(Gravity.LEFT,100,100)
        Toast.show()
    }
    private fun openDetailActivity(scoreuno: String, scoredos: String){
        val intent = Intent( this, DetailActivity::class.java)
        intent.putExtra("score_uno", scoreuno)
        intent.putExtra("score_dos", scoredos)
        startActivity(intent)

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        viewModel.scoreLocal.observe(this, Observer{
            localScoreValue ->
            binding.scoreUno.text = localScoreValue.toString()
        })
        viewModel = ViewModelProvider(this).get(MainViewModel::class.java)

        binding.detalles.setOnClickListener{
           val scoreuno = binding.scoreUno.text.toString()
            val scoredos = binding.scoreDos.text.toString()
            openDetailActivity(scoreuno, scoredos)
        }

        val textScoreLocal = findViewById<TextView>(R.id.scoreUno)
        val textScoreVisitante = findViewById<TextView>(R.id.scoreDos)


        textScoreLocal.text = viewModel.scoreLocal.toString()
        textScoreVisitante.text = viewModel.scoreVisitante.toString()
        /*acciones de los 3 botones local*/
        val unoSumaLocal = findViewById<Button>(R.id.unoSumaLocal)

        unoSumaLocal.setOnClickListener{
            viewModel.sumadepuntos()
            textScoreLocal.text = viewModel.scoreLocal.toString()
        }
        val dosSumaLocal = findViewById<Button>(R.id.dosSumaLocal)
        dosSumaLocal.setOnClickListener{
            viewModel.sumadedospuntos()
            textScoreLocal.text = viewModel.scoreLocal.toString()
        }
        val unoSumaVisitante = findViewById<Button>(R.id.unoSumaVisitante)

        unoSumaVisitante.setOnClickListener{
            viewModel.sumadepuntosVisitante()
            textScoreVisitante.text = viewModel.scoreVisitante.toString()
        }
        val dosSumaVisitante = findViewById<Button>(R.id.dosSumaVisitante)
        dosSumaVisitante.setOnClickListener{
            viewModel.sumadedospuntosVisitante()
            textScoreVisitante.text = viewModel.scoreVisitante.toString()
        }

        val restaLocal = findViewById<Button>(R.id.menosLocal)
        restaLocal.setOnClickListener {

            if (viewModel.scoreLocal <= 0) {
                val Toast = Toast.makeText(
                    applicationContext,
                    "No puedes tener un puntaje menor a cero en el marcador",
                    Toast.LENGTH_SHORT
                )
                Toast.setGravity(Gravity.LEFT, 100, -500)
                Toast.show()
            } else {
                viewModel.restadepuntos()
                textScoreLocal.text = viewModel.scoreLocal.toString()
            }
        }

            val restaVisitante = findViewById<Button>(R.id.menosVisitante)
            restaVisitante.setOnClickListener{

            if (viewModel.scoreVisitante <= 0)
            {
                val Toast = Toast.makeText(
                    applicationContext,
                    "No puedes tener un puntaje menor a cero en el marcador",
                    Toast.LENGTH_SHORT
                )
                Toast.setGravity(Gravity.LEFT, 100, -500)
                Toast.show()
            }
            else{
                viewModel.restadepuntosVisitante()
                textScoreVisitante.text = viewModel.scoreVisitante.toString()
            }
        }

        /* Botón de Reset */
        val restart = findViewById<Button>(R.id.restart)
        restart.setOnClickListener{

            openrestartactivity()
        }


    }
}